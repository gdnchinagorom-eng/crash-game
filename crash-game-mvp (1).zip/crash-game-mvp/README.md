# Crash Game — Mobile Browser MVP

A responsive, single-page crash-game prototype using **virtual coins only**. It has no deposits, withdrawals, purchasable coins, or cash redemption.

## Files
- `index.html` — complete playable game. CSS and JavaScript are included, so no build tools or dependencies are required.
- `README.md` — setup, hosting, and next steps.

## Run on a computer
1. Download and unzip the project.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox, or Safari).
3. Choose a bet (10–500 coins), press **Start round**, then press **Cash out** before the multiplier crashes.
4. Use **Reset demo** to restore 1,000 virtual coins.

Local browser storage remembers your virtual balance and recent results on the same browser/device. It is not a server account.

## Test on a phone
**Easy option:** upload `index.html` to a static host (see below), then open the generated website URL on your phone.

**Same Wi-Fi option:** if Python is installed on your computer:
1. Put `index.html` in a folder.
2. Open a terminal in that folder.
3. Run `python -m http.server 8000`
4. Find your computer's local IP address and open `http://YOUR-COMPUTER-IP:8000` on your phone while both devices are on the same Wi-Fi.
   - Windows: run `ipconfig` and look for the IPv4 address.
   - Some firewalls may ask permission to allow local network access.

## Free static hosting
Choose one:
- **GitHub Pages:** create a GitHub repository, upload `index.html`, then go to repository **Settings → Pages** and publish from the `main` branch / root folder.
- **Netlify Drop:** use Netlify's manual deploy / Drop page to upload the folder containing `index.html`. The provider's UI may change over time.

Hosting gives you a shareable website. It does not turn the project into a native Android/iPhone app. A browser-hosted site can later be made installable as a PWA, or wrapped for app stores after checking their current policies.

## Current MVP limitations
- The crash result uses `Math.random()` and a deliberately simple demo distribution. It is **not cryptographically secure, independently tested, or provably fair**.
- The balance and history are saved in the browser's `localStorage`; users can edit them, clear them, or use another device. Do not use this for real-money play.
- No backend, login, multiplayer, payment integration, analytics, or operator integration is included.
- The displayed auto cash-out is a gameplay convenience only. This demo is not a gambling product and coins have no cash value.

## Before commercial licensing
Do not add real-money deposits, withdrawals, or redeemable value to this prototype. Before approaching licensed operators, plan for:
1. Legal review of the exact supplier/operator model and applicable jurisdiction.
2. A server-authoritative round engine; clients must not decide results or balances.
3. Cryptographically secure randomness and a documented fairness protocol, with independent testing/certification where required.
4. Game math, return-to-player / house-edge documentation, risk controls, audit logs, and incident monitoring.
5. Security testing, privacy controls, responsible-gambling features, age controls, and anti-fraud/AML controls as applicable.
6. An operator integration API, test environment, technical documentation, support process, and commercial agreement.
7. Written confirmation of licensing, certification, and approval requirements from the relevant regulator and prospective operator.

**Important:** This is a learning/demo prototype, not legal, financial, or gambling compliance advice. A partner's licence does not automatically mean your supplier activity is exempt from regulation.
